<?php
/**
 * Created by PhpStorm.
 * User: WEBMOBILITY
 * Date: 4/13/2017
 * Time: 12:48 PM
 */
$host = 'localhost';
$user = 'root';
$password = '';
$db = 'yawwedsefua';
$con = mysqli_connect($host, $user, $password, $db) or die(mysqli_error($con));